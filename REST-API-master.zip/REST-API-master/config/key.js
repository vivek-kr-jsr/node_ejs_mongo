module.exports = {
    DB_CONNECT:" mongodb://127.0.0.1:27017/crud",
    TOKEN_SECRET:"gjoidjdwjddpokhw"
}
